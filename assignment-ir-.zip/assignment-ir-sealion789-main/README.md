# MIE 1513 Assignment: Information Retrieval (IR)

We will go through the tutorial notebook during the lab this week: [IR_Lab.ipynb](IR_Lab.ipynb)

For this assignment, please:

- Read the instruction PDF:  [MIE_1513_Decision_Support_Systems_Assignment_Information_Retrieval_IR.pdf](MIE_1513_Decision_Support_Systems_Assignment_Information_Retrieval_IR.pdf) 

- Complete and upload the assignment notebook: [ir_assignment.ipynb](ir_assignment.ipynb)

The zip file [government](https://github.com/MIE1513HS-2022/course-datasets) contains the dataset you will use in this assignment
