# MIE 1513 Assignment: python warmup

For this assignment, please:

- Fill the signup form provided on Quercus to provide your githubID and student information

- Read the instruction PDF:  [MIE_1513_Decision_Support_Systems_Assignment_Warmup__Introduction_to_Python.pdf](MIE_1513_Decision_Support_Systems_Assignment_Warmup__Introduction_to_Python.pdf) 

- Complete and upload the assignment notebook: [Python_Warmup.ipynb](Python_Warmup.ipynb) 

